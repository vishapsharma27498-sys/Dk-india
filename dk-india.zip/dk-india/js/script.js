/* =========================================================
   D.K. INDIA — store config
   >>> EDIT THESE TWO LINES BEFORE YOU PUBLISH <<<
   ========================================================= */
const WHATSAPP_NUMBER = "919999999999"; // country code + number, no + or spaces
const STORE_EMAIL      = "your-email@example.com"; // where order emails should land

/* =========================================================
   Product catalogue
   Edit / add / remove products here — the grid and order
   form update automatically.
   ========================================================= */
const PRODUCTS = [
  {
    sku: "DK-AWL-01",
    name: "Diamond Stitching Awl",
    desc: "Hand-forged diamond-point awl for clean, angled stitch holes. Comfortable turned-wood handle.",
    price: 349,
    icon: "awl"
  },
  {
    sku: "DK-EDG-04",
    name: "Edge Beveler (No. 2)",
    desc: "Shaves a smooth bevel off raw edges before burnishing. Sharpened and ready to use.",
    price: 429,
    icon: "blade"
  },
  {
    sku: "DK-GRV-03",
    name: "Adjustable Stitching Groover",
    desc: "Cuts a clean channel for your stitch line so thread sits flush and protected.",
    price: 389,
    icon: "blade"
  },
  {
    sku: "DK-MLT-02",
    name: "Rawhide Mallet, 8 oz",
    desc: "Weighted rawhide head for driving stitching chisels and setters without marking the leather.",
    price: 599,
    icon: "mallet"
  },
  {
    sku: "DK-CHS-06",
    name: "Diamond Pricking Chisel Set",
    desc: "Set of 3 — 2, 4 &amp; 6 prong — 3.85mm pitch, for even, machine-like hand stitching.",
    price: 1249,
    icon: "chisel"
  },
  {
    sku: "DK-KNF-05",
    name: "Leather Skiving Knife",
    desc: "Thins edges and seams for folds and turn-backs. High-carbon blade, holds an edge well.",
    price: 459,
    icon: "blade"
  },
  {
    sku: "DK-BRN-07",
    name: "Wooden Edge Slicker",
    desc: "Burnishes raw edges to a smooth, glass-like finish with a little water and friction.",
    price: 199,
    icon: "roll"
  },
  {
    sku: "DK-MAT-08",
    name: "Self-Healing Cutting Mat, A2",
    desc: "Double-sided grid mat that protects your bench and your blades. 5-layer PVC.",
    price: 899,
    icon: "mat"
  },
  {
    sku: "DK-PNC-09",
    name: "Rotary Leather Hole Punch",
    desc: "Six-size revolving punch head for belts, straps and buckle work. Solid steel body.",
    price: 549,
    icon: "punch"
  },
  {
    sku: "DK-THR-10",
    name: "Waxed Polyester Thread, 50m",
    desc: "Pre-waxed, tangle-resistant thread for hand stitching. Holds tension, resists fraying.",
    price: 129,
    icon: "thread"
  },
  {
    sku: "DK-CMT-11",
    name: "Bone Folder / Creaser",
    desc: "Scores clean fold lines and burnishes tight corners without scuffing the grain.",
    price: 179,
    icon: "roll"
  },
  {
    sku: "DK-STN-12",
    name: "Leather Strop with Compound",
    desc: "Double-sided strop plus honing compound to keep every edge tool shaving-sharp.",
    price: 379,
    icon: "roll"
  }
];

/* =========================================================
   Simple line icons per tool category (no external images
   needed — keeps the repo dependency-free)
   ========================================================= */
const ICONS = {
  awl: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 38 L34 14"/><circle cx="36" cy="12" r="3"/><path d="M8 40 L12 36" stroke-linecap="round"/></svg>`,
  blade: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><path d="M8 30 L30 8 L40 18 L18 40 Z"/><path d="M8 30 L18 40" /></svg>`,
  mallet: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><rect x="8" y="8" width="20" height="14" rx="2"/><path d="M20 22 L30 40" stroke-linecap="round"/></svg>`,
  chisel: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 6 L14 26 L20 40 L26 26 L26 6" /><path d="M14 26 L26 26"/></svg>`,
  roll: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><ellipse cx="24" cy="24" rx="16" ry="10"/><path d="M8 24 Q24 34 40 24"/></svg>`,
  mat: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="10" width="36" height="28" rx="2"/><path d="M6 20 H42 M6 28 H42 M16 10 V38 M32 10 V38"/></svg>`,
  punch: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="30" r="10"/><path d="M25 23 L40 8" stroke-linecap="round"/><circle cx="18" cy="30" r="3" fill="currentColor" stroke="none"/></svg>`,
  thread: `<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="2"><circle cx="24" cy="24" r="14"/><path d="M24 10 Q30 24 24 38 Q18 24 24 10 Z"/></svg>`
};

/* =========================================================
   Render product grid
   ========================================================= */
const grid = document.getElementById("productGrid");

function renderProducts(){
  grid.innerHTML = PRODUCTS.map((p, i) => `
    <article class="product-card">
      <div class="card-icon">${ICONS[p.icon] || ICONS.roll}</div>
      <p class="card-sku">${p.sku}</p>
      <h3 class="card-name">${p.name}</h3>
      <p class="card-desc">${p.desc}</p>
      <div class="card-footer">
        <span class="card-price">₹${p.price}<span>per piece</span></span>
        <button class="order-btn" data-index="${i}">Order Now</button>
      </div>
    </article>
  `).join("");
}
renderProducts();

/* =========================================================
   Order modal logic
   ========================================================= */
const overlay        = document.getElementById("orderOverlay");
const modalClose      = document.getElementById("modalClose");
const modalProductLine= document.getElementById("modalProductLine");
const modalTitle      = document.getElementById("modalTitle");
const orderForm       = document.getElementById("orderForm");
const orderSuccess    = document.getElementById("orderSuccess");
const successClose    = document.getElementById("successClose");
const submitBtn       = document.getElementById("submitBtn");

let activeProduct = null;

function openModal(product){
  activeProduct = product;
  document.getElementById("fProduct").value = product.name + " (" + product.sku + ")";
  document.getElementById("fPrice").value = product.price;
  modalTitle.textContent = "Order: " + product.name;
  modalProductLine.textContent = product.sku + " · ₹" + product.price + " per piece";
  orderForm.hidden = false;
  orderSuccess.hidden = true;
  overlay.classList.add("open");
  document.body.style.overflow = "hidden";
  document.getElementById("fName").focus();
}

function closeModal(){
  overlay.classList.remove("open");
  document.body.style.overflow = "";
}

grid.addEventListener("click", (e) => {
  const btn = e.target.closest(".order-btn");
  if (!btn) return;
  const product = PRODUCTS[btn.dataset.index];
  openModal(product);
});

modalClose.addEventListener("click", closeModal);
successClose.addEventListener("click", closeModal);
overlay.addEventListener("click", (e) => {
  if (e.target === overlay) closeModal();
});
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && overlay.classList.contains("open")) closeModal();
});

/* =========================================================
   Submit: opens WhatsApp with prefilled order text, and
   emails the store via FormSubmit (no backend needed).
   ========================================================= */
orderForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const name    = document.getElementById("fName").value.trim();
  const phone   = document.getElementById("fPhone").value.trim();
  const email   = document.getElementById("fEmail").value.trim();
  const qty     = document.getElementById("fQty").value.trim();
  const address = document.getElementById("fAddress").value.trim();
  const notes   = document.getElementById("fNotes").value.trim();

  const productLabel = activeProduct.name + " (" + activeProduct.sku + ")";

  const waText = [
    "New order — D.K. India",
    "Product: " + productLabel,
    "Quantity: " + qty,
    "Price: ₹" + activeProduct.price + " each",
    "Name: " + name,
    "Phone: " + phone,
    email ? "Email: " + email : null,
    "Address: " + address,
    notes ? "Notes: " + notes : null
  ].filter(Boolean).join("\n");

  const waLink = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(waText);

  submitBtn.disabled = true;
  submitBtn.textContent = "Sending...";

  // Send the order by email via FormSubmit's AJAX endpoint (static-site friendly).
  // First submission to a new email needs a one-time confirmation click —
  // see README for setup.
  try {
    await fetch("https://formsubmit.co/ajax/" + STORE_EMAIL, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Accept": "application/json" },
      body: JSON.stringify({
        _subject: "New order — " + productLabel,
        Product: productLabel,
        Quantity: qty,
        Price: "₹" + activeProduct.price,
        Name: name,
        Phone: phone,
        Email: email || "(not provided)",
        Address: address,
        Notes: notes || "(none)"
      })
    });
  } catch (err) {
    // Even if the email send fails (e.g. offline), we still hand the
    // order off to WhatsApp below so the order isn't lost.
    console.warn("Email send failed, continuing with WhatsApp:", err);
  }

  window.open(waLink, "_blank");

  orderForm.hidden = true;
  orderSuccess.hidden = false;
  submitBtn.disabled = false;
  submitBtn.textContent = "Send Order via WhatsApp & Email";
  orderForm.reset();
});

/* =========================================================
   Footer quick links + year
   ========================================================= */
document.getElementById("footerWhatsapp").href =
  "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent("Hi D.K. India, I'd like to ask about a tool.");
document.getElementById("footerEmail").href = "mailto:" + STORE_EMAIL;
document.getElementById("year").textContent = new Date().getFullYear();
