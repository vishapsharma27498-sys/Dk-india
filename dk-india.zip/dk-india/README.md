# D.K. India — Leathercraft Tool Store

Ek simple, fast, static shopping site — leathercraft tools (awl, edge beveler,
stitching iron, mallet, waxed thread, etc.) sell karne ke liye. Koi backend
server nahi chahiye — seedha GitHub Pages par free host ho jaati hai.

**Feature:** Kisi bhi product par "Order Now" click karte hi ek form khulta
hai. Form submit hote hi:
1. WhatsApp khulta hai order details ke saath pre-filled message ke sath.
2. Order details aapke email par bhi chali jaati hai (bina kisi backend ke,
   FormSubmit service ke through).

---

## 1. Apni details daalein (ZARURI)

`js/script.js` file kholein, sabse upar ye do lines change karein:

```js
const WHATSAPP_NUMBER = "919999999999"; // apna number, country code ke saath, + ya space mat lagayein
const STORE_EMAIL      = "your-email@example.com"; // jahan order emails aani chahiye
```

Example: agar aapka number `9876543210` hai to likhein `"919876543210"`.

## 2. Email service activate karna (sirf ek baar)

Ye site emails bhejne ke liye [FormSubmit.co](https://formsubmit.co) use
karti hai — ye free hai aur koi sign-up nahi chahiye.

- Site live karne ke baad, ek test order form submit karein.
- FormSubmit aapke diye gaye email par ek **confirmation email** bhejega.
- Us email me diye gaye link par click karke activate kar dein.
- Uske baad se saari orders seedha aapke inbox me aayengi.

(Agar confirmation email nahi mile, spam/junk folder check karein.)

## 3. Products edit karna

`js/script.js` me `PRODUCTS` array me har product ka naam, SKU, description
aur price diya hua hai — jitne chaho add/remove/edit kar sakte ho, grid
automatically update ho jaayega.

## 4. Apna logo/naam change karna

`index.html` me `D.K. INDIA` naam jagah-jagah hai (header, hero, footer) —
find & replace se apna brand naam daal sakte hain.

---

## GitHub par daalna (deploy karna)

1. GitHub par ek naya repository banayein (e.g. `dk-india`).
2. Is poore folder (`index.html`, `css/`, `js/`, `README.md`) ko us repo me
   upload/push kar dein.
3. Repo ke **Settings → Pages** me jaakar:
   - Source: `Deploy from a branch`
   - Branch: `main` / root
   - Save karein.
4. Kuch minute me aapki site `https://<username>.github.io/dk-india/` par
   live ho jaayegi.

### Command line se (agar Git install hai)

```bash
git init
git add .
git commit -m "D.K. India store — first version"
git branch -M main
git remote add origin https://github.com/<your-username>/dk-india.git
git push -u origin main
```

---

## File structure

```
dk-india/
├── index.html          → poori site (sections: hero, shop, story, tool care, footer)
├── css/
│   └── style.css        → design (leather/saddle theme, stitched borders)
├── js/
│   └── script.js        → product data + order form + WhatsApp/email logic
└── README.md
```

Koi build step nahi hai — ye plain HTML/CSS/JS hai, seedha browser me khul
jaati hai (`index.html` double-click karke bhi locally dekh sakte ho).
